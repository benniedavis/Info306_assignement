<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp_info306_lab_session1' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'I48O>c~*qqVX$GB+O8*P;N3,o/anQh]l=4]tVI;u|4aK3#9~[s6)<.=Y3.DU_*n_' );
define( 'SECURE_AUTH_KEY',  ',:It`o< i0?-KCCqmnls0-l<,vAmxZ5 1n)T**;WE:z9gRzz`h>`h7&g(/UU)p=5' );
define( 'LOGGED_IN_KEY',    'CjVBr|#9J{5 W)?~FV.q[:#uOD-A2[gsi+Sy7%m@4z`LZ B.e.;IBpueIlS2G}rd' );
define( 'NONCE_KEY',        '?gEU@~8^ &*;:p%O]0_1nB0$S972b7.M:O>kv[<MQt/-AVn(arLvSt.2;PY!~Dj ' );
define( 'AUTH_SALT',        '^XV4@1e=(Gj8+nUXrF5+Ef:.{qM.HoV,G2c!=)Q~co#x@8cO6WPL>V=p E=pYkJ&' );
define( 'SECURE_AUTH_SALT', 'jA`;gBC.yV31W+52w8`b@,mh1RR6 +8pd@2{N*)}A7PG}4D^?:8.SUFA5tO0s|3f' );
define( 'LOGGED_IN_SALT',   'YQ_OVh.^bb3Vn_0<&%=5RR!ZmCQ/NoBa^/K1+aoPKY]S$|owA?|#ojkXwl28nteD' );
define( 'NONCE_SALT',       '8.@`aVWB:U89EDaVlBVAj]m]?p1,Q?o?5=jOQ`=Tl(/;u$Ss>5z% =G~9CAm(z,:' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
